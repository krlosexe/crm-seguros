<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BenefitsHosting extends Model
{
    protected $table         = 'benefits_hosting';
    public    $timestamps    = false;
    protected $primaryKey    = 'id_benefits_hosting';
}
