<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerSupportHosting extends Model
{
    protected $table         = 'customer_support_hosting';
    public    $timestamps    = false;
    protected $primaryKey    = 'id_custumer_support_hosting';



    


}
