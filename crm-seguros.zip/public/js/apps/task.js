// Task JavaScripts

(function ($) {
	'use strict';
      
    dragula([board1, board2, board3]);

})(jQuery);
