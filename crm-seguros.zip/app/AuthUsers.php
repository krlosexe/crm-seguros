<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AuthUsers extends Model
{
    protected $table   = 'auth_users';
    public $timestamps = false;
}
