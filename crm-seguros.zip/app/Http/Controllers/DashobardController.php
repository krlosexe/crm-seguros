<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashobardController extends Controller
{
    public function index()
    {
    	echo "string";
    }
}
