<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WayToPayHosting extends Model
{
    protected $table         = 'way_to_pay_hosting';
    public    $timestamps    = false;
    protected $primaryKey    = 'id_way_to_pay_hosting';
}
